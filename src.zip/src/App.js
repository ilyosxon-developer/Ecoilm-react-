import './App.css';

import Link from './Link/link.js';
function App() {
  return (
    <div className="App"> 
     <Link/>
     {/* <IlmiyJural/> */}
    </div>
  );
}

export default App;
